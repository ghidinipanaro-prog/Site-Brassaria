package br.com.brassaria;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ApiIntegrationTest {
    @Autowired MockMvc mvc;

    @Test
    void ultimosRetornaSomenteTresEventos() throws Exception {
        mvc.perform(get("/api/eventos/ultimos"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.length()").value(3));
    }

    @Test
    void bebidasVemComCategoria() throws Exception {
        mvc.perform(get("/api/bebidas"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$[0].categoria").isNotEmpty());
    }

    @Test
    void cadastroSemLoginEhNegado() throws Exception {
        mvc.perform(post("/api/eventos").contentType(MediaType.APPLICATION_JSON).content("{}"))
           .andExpect(status().isUnauthorized());
    }

    @Test
    void cadastroComLoginCriaEventoComBebidas() throws Exception {
        String corpo = "{\"titulo\":\"Evento de teste\",\"dataEvento\":\"2026-12-20\",\"local\":\"SP\",\"bebidaIds\":[1]}";
        mvc.perform(post("/api/eventos").with(httpBasic("admin", "admin123"))
                .contentType(MediaType.APPLICATION_JSON).content(corpo))
           .andExpect(status().isCreated())
           .andExpect(jsonPath("$.titulo").value("Evento de teste"))
           .andExpect(jsonPath("$.bebidas.length()").value(1));
    }

    @Test
    void cadastroInvalidoRetorna400() throws Exception {
        mvc.perform(post("/api/eventos").with(httpBasic("admin", "admin123"))
                .contentType(MediaType.APPLICATION_JSON).content("{}"))
           .andExpect(status().isBadRequest())
           .andExpect(jsonPath("$.campos.titulo").exists());
    }
}
