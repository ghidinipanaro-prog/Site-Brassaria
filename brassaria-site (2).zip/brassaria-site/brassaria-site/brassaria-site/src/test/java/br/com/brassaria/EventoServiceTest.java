package br.com.brassaria;

import br.com.brassaria.dto.EventoRequest;
import br.com.brassaria.exception.RecursoNaoEncontradoException;
import br.com.brassaria.repository.BebidaRepository;
import br.com.brassaria.repository.EventoRepository;
import br.com.brassaria.service.EventoService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyIterable;
import static org.mockito.Mockito.when;

class EventoServiceTest {
    @Test
    void bebidaInexistenteLancaExcecao() {
        BebidaRepository bebidas = Mockito.mock(BebidaRepository.class);
        when(bebidas.findAllById(anyIterable())).thenReturn(List.of());
        EventoService service = new EventoService(Mockito.mock(EventoRepository.class), bebidas);

        EventoRequest dados = new EventoRequest("Teste", LocalDate.now(), "SP", null, Set.of(99L));
        assertThrows(RecursoNaoEncontradoException.class, () -> service.cadastrar(dados));
    }
}
