const msg = document.querySelector('#msg');
const caixa = document.querySelector('#bebidas');

fetch('/api/bebidas')
  .then((r) => r.json())
  .then((bebidas) => bebidas.forEach((b) => {
    const rotulo = document.createElement('label');
    const marcar = document.createElement('input');
    marcar.type = 'checkbox';
    marcar.name = 'bebida';
    marcar.value = b.id;
    rotulo.append(marcar, b.nome);
    caixa.append(rotulo);
  }))
  .catch(() => { caixa.append('Não foi possível carregar as bebidas.'); });

document.querySelector('#form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = new FormData(ev.target);
  const corpo = {
    titulo: f.get('titulo'),
    dataEvento: f.get('dataEvento'),
    local: f.get('local'),
    descricao: f.get('descricao'),
    bebidaIds: f.getAll('bebida').map(Number),
  };
  try {
    const r = await fetch('/api/eventos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Basic ' + btoa(f.get('usuario') + ':' + f.get('senha')),
      },
      body: JSON.stringify(corpo),
    });
    if (r.status === 201) {
      msg.textContent = 'Evento publicado. Ele já aparece na página inicial.';
      ev.target.reset();
    } else if (r.status === 401) {
      msg.textContent = 'Usuário ou senha incorretos.';
    } else {
      msg.textContent = 'Preencha o título e a data do evento.';
    }
  } catch {
    msg.textContent = 'Não foi possível falar com o servidor. Tente de novo.';
  }
});
