const $ = (s) => document.querySelector(s);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};
const api = async (url) => {
  const r = await fetch(url);
  if (!r.ok) throw new Error(url + ' ' + r.status);
  return r.json();
};
const parseData = (s) => { const [a, m, d] = s.split('-').map(Number); return new Date(a, m - 1, d); };
const semAlcool = (b) => Number(b.teorAlcoolico) === 0;

function renderInstitucional(itens) {
  const por = Object.fromEntries(itens.map((i) => [i.tipo, i]));
  $('#hero-titulo').textContent = por.HERO.titulo;
  $('#hero-texto').textContent = por.HERO.texto;
  $('#cap-num').textContent = por.ANIVERSARIO.titulo;
  $('#cap-txt').textContent = por.ANIVERSARIO.texto;
  $('#saude-titulo').textContent = por.SAUDE.titulo;
  $('#saude-texto').textContent = por.SAUDE.texto;
  $('#aviso-titulo').textContent = por.AVISO.titulo + '.';
  $('#aviso-texto').textContent = por.AVISO.texto;
  const mvv = $('#mvv');
  ['MISSAO', 'VISAO', 'VALORES'].forEach((t) => {
    const c = el('article', 'card');
    c.append(el('h3', null, por[t].titulo), el('p', null, por[t].texto));
    mvv.append(c);
  });
}

function renderEventos(eventos) {
  const box = $('#lista-eventos');
  if (!eventos.length) { box.append(el('p', null, 'Ainda não há eventos cadastrados.')); return; }
  eventos.forEach((e) => {
    const data = parseData(e.dataEvento).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
    const c = el('article', 'card');
    c.append(el('span', 'data', data), el('h3', null, e.titulo));
    if (e.local) c.append(el('p', 'meta', e.local));
    if (e.descricao) c.append(el('p', null, e.descricao));
    if (e.bebidas.length) c.append(el('p', 'meta', 'Para provar: ' + e.bebidas.join(', ')));
    box.append(c);
  });
}

function renderBebidas(bebidas) {
  const lista = $('#lista-bebidas');
  const filtros = { todas: () => true, alcool: (b) => !semAlcool(b), zero: semAlcool };
  const rotulos = { todas: 'Todas', alcool: 'Com álcool', zero: 'Sem álcool' };

  const desenhar = (chave) => {
    lista.replaceChildren();
    bebidas.filter(filtros[chave]).forEach((b) => {
      const c = el('article', 'card bebida' + (semAlcool(b) ? ' zero' : ''));
      c.append(el('p', 'meta', b.categoria), el('h3', null, b.nome), el('p', null, b.descricao));
      c.append(el('span', 'teor', semAlcool(b) ? 'Sem álcool' : 'Teor alcoólico: ' + Number(b.teorAlcoolico).toLocaleString('pt-BR') + '%'));
      lista.append(c);
    });
  };

  Object.keys(filtros).forEach((chave) => {
    const bt = el('button', null, rotulos[chave]);
    bt.type = 'button';
    bt.setAttribute('aria-pressed', chave === 'todas');
    bt.addEventListener('click', () => {
      document.querySelectorAll('#filtros button').forEach((x) => x.setAttribute('aria-pressed', x === bt));
      desenhar(chave);
    });
    $('#filtros').append(bt);
  });
  desenhar('todas');
}

Promise.all([api('/api/institucional'), api('/api/eventos/ultimos'), api('/api/bebidas')])
  .then(([inst, eventos, bebidas]) => {
    renderInstitucional(inst);
    renderEventos(eventos);
    renderBebidas(bebidas);
  })
  .catch(() => {
    $('#hero-titulo').textContent = 'Não foi possível carregar o site.';
    $('#hero-texto').textContent = 'Verifique se o servidor está no ar e atualize a página.';
  });
