package br.com.brassaria.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Getter @Setter
public class ConteudoInstitucional {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, unique = true, length = 20)
    private TipoConteudo tipo;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false, length = 2000)
    private String texto;
}
