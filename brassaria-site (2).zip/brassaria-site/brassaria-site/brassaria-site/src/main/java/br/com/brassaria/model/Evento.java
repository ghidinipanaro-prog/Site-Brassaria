package br.com.brassaria.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity @Getter @Setter
public class Evento {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String titulo;

    @Column(nullable = false)
    private LocalDate dataEvento;

    @Column(name = "local_evento", length = 150)
    private String local;

    @Column(length = 2000)
    private String descricao;

    @Column(nullable = false, updatable = false)
    private LocalDateTime dataCadastro;

    /** Bebidas apresentadas no evento (N:N, tabela evento_bebida). */
    @ManyToMany
    @JoinTable(name = "evento_bebida",
            joinColumns = @JoinColumn(name = "evento_id"),
            inverseJoinColumns = @JoinColumn(name = "bebida_id"))
    private Set<Bebida> bebidas = new LinkedHashSet<>();

    @PrePersist
    void aoCadastrar() { dataCadastro = LocalDateTime.now(); }
}
