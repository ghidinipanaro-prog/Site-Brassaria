package br.com.brassaria.repository;

import br.com.brassaria.model.ConteudoInstitucional;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ConteudoInstitucionalRepository extends JpaRepository<ConteudoInstitucional, Long> {
    List<ConteudoInstitucional> findAllByOrderByIdAsc();
}
