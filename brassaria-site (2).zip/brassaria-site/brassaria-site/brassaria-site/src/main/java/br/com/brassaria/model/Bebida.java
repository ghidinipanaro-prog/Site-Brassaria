package br.com.brassaria.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity @Getter @Setter
public class Bebida {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String nome;

    @Column(length = 500)
    private String descricao;

    /** 0 = sem álcool. */
    @Column(nullable = false, precision = 4, scale = 1)
    private BigDecimal teorAlcoolico = BigDecimal.ZERO;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    @ManyToMany(mappedBy = "bebidas")
    private Set<Evento> eventos = new LinkedHashSet<>();
}
