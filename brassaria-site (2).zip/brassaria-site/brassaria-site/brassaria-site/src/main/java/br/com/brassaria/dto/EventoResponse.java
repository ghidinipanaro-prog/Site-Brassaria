package br.com.brassaria.dto;

import br.com.brassaria.model.Bebida;
import br.com.brassaria.model.Evento;
import java.time.LocalDate;
import java.util.List;

public record EventoResponse(Long id, String titulo, LocalDate dataEvento, String local, String descricao, List<String> bebidas) {
    public static EventoResponse de(Evento e) {
        return new EventoResponse(e.getId(), e.getTitulo(), e.getDataEvento(), e.getLocal(), e.getDescricao(),
                e.getBebidas().stream().map(Bebida::getNome).toList());
    }
}
