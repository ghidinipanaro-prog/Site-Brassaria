package br.com.brassaria.dto;

import br.com.brassaria.model.Bebida;
import java.math.BigDecimal;

public record BebidaResponse(Long id, String nome, String categoria, BigDecimal teorAlcoolico, String descricao) {
    public static BebidaResponse de(Bebida b) {
        return new BebidaResponse(b.getId(), b.getNome(), b.getCategoria().getNome(), b.getTeorAlcoolico(), b.getDescricao());
    }
}
