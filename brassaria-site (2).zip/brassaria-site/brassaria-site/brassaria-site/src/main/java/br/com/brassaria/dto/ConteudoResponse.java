package br.com.brassaria.dto;

import br.com.brassaria.model.ConteudoInstitucional;

public record ConteudoResponse(String tipo, String titulo, String texto) {
    public static ConteudoResponse de(ConteudoInstitucional c) {
        return new ConteudoResponse(c.getTipo().name(), c.getTitulo(), c.getTexto());
    }
}
