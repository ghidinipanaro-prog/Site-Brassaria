package br.com.brassaria.config;

import br.com.brassaria.model.*;
import br.com.brassaria.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Carga inicial: roda só se o banco estiver vazio, então não duplica dados a cada reinício. */
@Component
public class CarregadorDeDados implements CommandLineRunner {
    private final CategoriaRepository categorias;
    private final BebidaRepository bebidas;
    private final EventoRepository eventos;
    private final ConteudoInstitucionalRepository conteudos;

    public CarregadorDeDados(CategoriaRepository categorias, BebidaRepository bebidas,
                             EventoRepository eventos, ConteudoInstitucionalRepository conteudos) {
        this.categorias = categorias;
        this.bebidas = bebidas;
        this.eventos = eventos;
        this.conteudos = conteudos;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (categorias.count() > 0) return;

        conteudo(TipoConteudo.ANIVERSARIO, "780", "anos de história");
        conteudo(TipoConteudo.HERO, "Brindamos a vida há 780 anos.", "A Brassaria Internacional é uma das fabricantes de cervejas e bebidas fermentadas mais tradicionais do Brasil. Em 2026 celebramos nossa história com quem faz parte dela: você.");
        conteudo(TipoConteudo.MISSAO, "Missão", "Produzir bebidas de qualidade que acompanham bons encontros, e informar nossos clientes para que cada escolha, com ou sem álcool, seja feita com consciência.");
        conteudo(TipoConteudo.VISAO, "Visão", "Ser a marca de bebidas mais admirada do Brasil por unir tradição, inovação e cuidado com a saúde de quem consome.");
        conteudo(TipoConteudo.VALORES, "Valores", "Qualidade em cada lote. Respeito ao consumidor. Consumo responsável. Transparência sobre o que vai em cada garrafa. Alegria que inclui todo mundo à mesa.");
        conteudo(TipoConteudo.SAUDE, "Beber bem é beber com consciência", "O consumo de bebidas industrializadas, alcoólicas ou não, faz parte do estilo de vida e da saúde. Por isso mostramos o teor alcoólico de cada produto, mantemos opções sem álcool em todas as linhas e promovemos o consumo moderado e informado.");
        conteudo(TipoConteudo.AVISO, "Beba com moderação", "Venda e consumo proibidos para menores de 18 anos. Se dirigir, não beba. Gestantes não devem consumir álcool.");

        Categoria cerveja = categorias.save(categoria("Cerveja"));
        Categoria cervejaZero = categorias.save(categoria("Cerveja sem álcool"));
        Categoria fermentada = categorias.save(categoria("Fermentada sem álcool"));

        Bebida pilsen = bebida("Brassaria Pilsen Clássica", cerveja, "4.8", "Leve, dourada e refrescante. A receita que começou nossa história.");
        Bebida weiss = bebida("Brassaria Weiss", cerveja, "5.0", "Cerveja de trigo com notas de banana e cravo, de espuma cremosa.");
        Bebida ipa = bebida("Brassaria IPA 780", cerveja, "6.2", "Edição comemorativa com lúpulo cítrico e amargor marcante.");
        Bebida stout = bebida("Brassaria Stout Noite Longa", cerveja, "5.5", "Escura, com notas de café e chocolate amargo.");
        Bebida zero = bebida("Brassaria Zero", cervejaZero, "0.0", "O sabor da nossa Pilsen, sem álcool. Para qualquer ocasião.");
        Bebida kombucha = bebida("Kombucha Limão e Gengibre", fermentada, "0.0", "Fermentação natural, levemente ácida e gaseificada.");

        // Cadastrados do mais antigo ao mais recente: a tela inicial mostra os 3 últimos.
        evento("Roda de conversa: beber com consciência", "2026-10-30", "Sede da Brassaria, São Paulo", "Especialistas em saúde falam sobre consumo moderado e como escolher o que beber.", zero, kombucha);
        evento("Degustação guiada de cervejas artesanais", "2026-11-07", "Cervejaria-escola, Campinas", "Harmonização com petiscos e conversa com os mestres cervejeiros.", pilsen, weiss, ipa, stout);
        evento("Festival Brassaria 780 anos", "2026-11-21", "Parque da Cidade, São Paulo", "Música, gastronomia e um dia inteiro de celebração com entrada gratuita.", pilsen, ipa, zero);
        evento("Tarde sem álcool: sabores do verão", "2026-12-05", "Espaço Brassaria, Rio de Janeiro", "Experimente nossa linha sem álcool em drinks, kombuchas e receitas leves.", zero, kombucha);
    }

    private void conteudo(TipoConteudo tipo, String titulo, String texto) {
        ConteudoInstitucional c = new ConteudoInstitucional();
        c.setTipo(tipo);
        c.setTitulo(titulo);
        c.setTexto(texto);
        conteudos.save(c);
    }

    private Categoria categoria(String nome) {
        Categoria c = new Categoria();
        c.setNome(nome);
        return c;
    }

    private Bebida bebida(String nome, Categoria categoria, String teor, String descricao) {
        Bebida b = new Bebida();
        b.setNome(nome);
        b.setCategoria(categoria);
        b.setTeorAlcoolico(new BigDecimal(teor));
        b.setDescricao(descricao);
        return bebidas.save(b);
    }

    private void evento(String titulo, String data, String local, String descricao, Bebida... servidas) {
        Evento e = new Evento();
        e.setTitulo(titulo);
        e.setDataEvento(LocalDate.parse(data));
        e.setLocal(local);
        e.setDescricao(descricao);
        e.getBebidas().addAll(java.util.List.of(servidas));
        eventos.save(e);
    }
}
