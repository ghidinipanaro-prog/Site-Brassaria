package br.com.brassaria.repository;

import br.com.brassaria.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EventoRepository extends JpaRepository<Evento, Long> {
    List<Evento> findTop3ByOrderByDataCadastroDescIdDesc();
    List<Evento> findAllByOrderByDataCadastroDescIdDesc();
}
