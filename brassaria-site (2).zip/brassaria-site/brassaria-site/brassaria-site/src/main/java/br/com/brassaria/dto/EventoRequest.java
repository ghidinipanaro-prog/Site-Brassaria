package br.com.brassaria.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.Set;

public record EventoRequest(
        @NotBlank(message = "Informe o título.") @Size(max = 150, message = "Use até 150 caracteres.") String titulo,
        @NotNull(message = "Informe a data do evento.") LocalDate dataEvento,
        @Size(max = 150, message = "Use até 150 caracteres.") String local,
        @Size(max = 2000, message = "Use até 2000 caracteres.") String descricao,
        Set<Long> bebidaIds) { }
