package br.com.brassaria.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

/** Uma categoria agrupa várias bebidas (1:N). */
@Entity @Getter @Setter
public class Categoria {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 80)
    private String nome;

    @OneToMany(mappedBy = "categoria")
    private List<Bebida> bebidas = new ArrayList<>();
}
