package br.com.brassaria.controller;

import br.com.brassaria.dto.ConteudoResponse;
import br.com.brassaria.service.ConteudoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/institucional")
public class InstitucionalController {
    private final ConteudoService service;

    public InstitucionalController(ConteudoService service) { this.service = service; }

    @GetMapping
    public List<ConteudoResponse> listar() { return service.listar(); }
}
