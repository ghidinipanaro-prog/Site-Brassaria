package br.com.brassaria.model;

public enum TipoConteudo { ANIVERSARIO, HERO, MISSAO, VISAO, VALORES, SAUDE, AVISO }
