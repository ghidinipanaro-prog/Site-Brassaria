package br.com.brassaria.controller;

import br.com.brassaria.dto.BebidaResponse;
import br.com.brassaria.service.BebidaService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/bebidas")
public class BebidaController {
    private final BebidaService service;

    public BebidaController(BebidaService service) { this.service = service; }

    @GetMapping
    public List<BebidaResponse> listar() { return service.listar(); }
}
