package br.com.brassaria.service;

import br.com.brassaria.dto.BebidaResponse;
import br.com.brassaria.repository.BebidaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class BebidaService {
    private final BebidaRepository bebidas;

    public BebidaService(BebidaRepository bebidas) { this.bebidas = bebidas; }

    public List<BebidaResponse> listar() {
        return bebidas.findAllComCategoria().stream().map(BebidaResponse::de).toList();
    }
}
