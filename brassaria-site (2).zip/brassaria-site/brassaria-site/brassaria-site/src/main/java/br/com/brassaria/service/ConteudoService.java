package br.com.brassaria.service;

import br.com.brassaria.dto.ConteudoResponse;
import br.com.brassaria.repository.ConteudoInstitucionalRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class ConteudoService {
    private final ConteudoInstitucionalRepository conteudos;

    public ConteudoService(ConteudoInstitucionalRepository conteudos) { this.conteudos = conteudos; }

    public List<ConteudoResponse> listar() {
        return conteudos.findAllByOrderByIdAsc().stream().map(ConteudoResponse::de).toList();
    }
}
