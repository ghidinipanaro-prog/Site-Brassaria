package br.com.brassaria.controller;

import br.com.brassaria.dto.EventoRequest;
import br.com.brassaria.dto.EventoResponse;
import br.com.brassaria.service.EventoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/eventos")
public class EventoController {
    private final EventoService service;

    public EventoController(EventoService service) { this.service = service; }

    @GetMapping
    public List<EventoResponse> listar() { return service.listar(); }

    @GetMapping("/ultimos")
    public List<EventoResponse> ultimos() { return service.ultimos(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EventoResponse cadastrar(@Valid @RequestBody EventoRequest dados) { return service.cadastrar(dados); }
}
