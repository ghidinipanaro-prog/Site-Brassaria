package br.com.brassaria.repository;

import br.com.brassaria.model.Bebida;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface BebidaRepository extends JpaRepository<Bebida, Long> {
    @Query("select b from Bebida b join fetch b.categoria order by b.id")
    List<Bebida> findAllComCategoria();
}
