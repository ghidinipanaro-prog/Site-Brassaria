package br.com.brassaria.service;

import br.com.brassaria.dto.EventoRequest;
import br.com.brassaria.dto.EventoResponse;
import br.com.brassaria.exception.RecursoNaoEncontradoException;
import br.com.brassaria.model.Bebida;
import br.com.brassaria.model.Evento;
import br.com.brassaria.repository.BebidaRepository;
import br.com.brassaria.repository.EventoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional(readOnly = true)
public class EventoService {
    private final EventoRepository eventos;
    private final BebidaRepository bebidas;

    public EventoService(EventoRepository eventos, BebidaRepository bebidas) {
        this.eventos = eventos;
        this.bebidas = bebidas;
    }

    public List<EventoResponse> listar() {
        return eventos.findAllByOrderByDataCadastroDescIdDesc().stream().map(EventoResponse::de).toList();
    }

    /** Regra da tela inicial: os 3 últimos eventos cadastrados. */
    public List<EventoResponse> ultimos() {
        return eventos.findTop3ByOrderByDataCadastroDescIdDesc().stream().map(EventoResponse::de).toList();
    }

    @Transactional
    public EventoResponse cadastrar(EventoRequest dados) {
        Evento evento = new Evento();
        evento.setTitulo(dados.titulo());
        evento.setDataEvento(dados.dataEvento());
        evento.setLocal(dados.local());
        evento.setDescricao(dados.descricao());
        evento.setBebidas(buscarBebidas(dados.bebidaIds()));
        return EventoResponse.de(eventos.save(evento));
    }

    private Set<Bebida> buscarBebidas(Set<Long> ids) {
        if (ids == null || ids.isEmpty()) return new LinkedHashSet<>();
        List<Bebida> encontradas = bebidas.findAllById(ids);
        if (encontradas.size() != ids.size()) {
            throw new RecursoNaoEncontradoException("Alguma das bebidas informadas não existe.");
        }
        return new LinkedHashSet<>(encontradas);
    }
}
