# Brassaria Internacional: site institucional

Java 21 + Spring Boot 3, PostgreSQL e front-end estático (HTML/CSS/JS) servido pelo Spring.
Todo conteúdo exibido (textos, bebidas, eventos) é lido da API REST.

## Executar
    docker compose up -d        # sobe o PostgreSQL
    mvn spring-boot:run         # habilite o Lombok na IDE
Abra http://localhost:8080. Cadastro de eventos: http://localhost:8080/cadastro.html (admin / admin123).
Na primeira execução o Hibernate cria as tabelas e o `CarregadorDeDados` insere dados de exemplo (só se o banco estiver vazio).
Testes: `mvn test` (usam H2 em memória, perfil `test`).

## Arquitetura em camadas
    Front-end (static/)  --HTTP/JSON-->  Controller  ->  Service  ->  Repository  ->  PostgreSQL
                                          (DTOs)        (regras,      (Spring Data
                                                         transação)    JPA/Hibernate)

| Camada | Pacote | Responsabilidade |
|---|---|---|
| Apresentação | `controller` | Rotas REST e códigos HTTP; sem regra de negócio |
| Negócio | `service` | Regras (3 últimos eventos, validação das bebidas) e transações |
| Persistência | `repository` | Spring Data JPA |
| Domínio | `model` | Entidades JPA e relacionamentos |
| Contrato | `dto` | Records de entrada/saída; a entidade nunca vai direto ao JSON |
| Erros | `exception` | `@RestControllerAdvice` com respostas 400/404 padronizadas |
| Configuração | `config` | Segurança (POST protegido) e carga inicial |

Padrões: Layered Architecture, Repository, DTO, injeção de dependência por construtor, tratamento global de exceções.

## Modelo de dados (gerado pelo Hibernate)
```mermaid
erDiagram
    CATEGORIA ||--o{ BEBIDA : "possui (1:N)"
    EVENTO }o--o{ BEBIDA : "evento_bebida (N:N)"
    CATEGORIA { bigint id PK  string nome }
    BEBIDA { bigint id PK  string nome  decimal teor_alcoolico  bigint categoria_id FK }
    EVENTO { bigint id PK  string titulo  date data_evento  datetime data_cadastro }
    CONTEUDO_INSTITUCIONAL { bigint id PK  string tipo  string titulo  string texto }
```

## API
| Método | Rota | Descrição |
|---|---|---|
| GET | /api/institucional | Hero, missão, visão, valores, saúde e aviso |
| GET | /api/bebidas | Portfólio (com categoria) |
| GET | /api/eventos | Todos os eventos |
| GET | /api/eventos/ultimos | 3 últimos cadastrados (tela inicial) |
| POST | /api/eventos | Cadastra evento, com `bebidaIds` opcional (exige login) |
